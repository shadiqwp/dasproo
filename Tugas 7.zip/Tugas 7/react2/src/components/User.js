import Info from './info';
import React, {Component} from 'react';

export default function (props) {
    return (
        <div>
            <h1> Ini Halaman User</h1>
            <Info/>
        </div>
    );
}