import React, {Component} from 'react';

class Info extends Component {
    render(){
        return(
            <div>
                <h1> Info Page </h1>
                <p> Pemprograman Framework : React</p>
            </div>
        )
    }
}

export default Info;