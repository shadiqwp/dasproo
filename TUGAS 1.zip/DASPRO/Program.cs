﻿//Shadiq Widi Putra
//NIM 2207112581

using System;

namespace dasarPemrograman

{
    class Program
    {
        //Main Method    
        static void Main(string[] args)
        {
                    //Deklarasi Variabel
                    const int a = 10;
                    const int b = 5;
                    const int c = 2;
                    int tambah = a+b+c;
                    int kali = a*b*c;
                    int kurang = a-b-c;
                    int bagi = a/b/c;
                    

                    //Menuliskan Narasi
                    Console.WriteLine("anda adalah agen rahasia yang bertugas mendapatkan data dari server");
                    Console.WriteLine("Akses ke server membutuhkan password yang tidak diketahui...");
                    Console.WriteLine("- Password terdiri dari 4 angka");
                    Console.WriteLine("- Jika ditambahkan hasilnya = "+tambah);
                    Console.WriteLine("- Jika dikalikan hasilnya = "+kali);
                    Console.WriteLine("- Jika dikurangkan hasilnya = "+kurang);
                    Console.WriteLine("- Jika dibagikan hasilanya = "+bagi);

                    Console.Write("Enter Code : ");
        }

    }
}