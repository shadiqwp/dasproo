﻿using System;

namespace SOAL_UTS_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //inisialisasi variabel
            string nama;
            string nim;
            string konsentrasi;

            Console.WriteLine("Nama : ");
            nama = Console.ReadLine();

            Console.WriteLine("NIM : ");
            nim = Console.ReadLine();

            Console.WriteLine("Konsentrasi : ");
            konsentrasi = Console.ReadLine();

            Console.WriteLine("|*******************************|");
            Console.WriteLine("{0,-8} {1,24}", "|Nama:", nama+"|");
            Console.WriteLine("{0,-16} {1,16}", "|", nim+"|");
            Console.WriteLine("|-------------------------------|");
            Console.WriteLine("{0,-16} {1,16}", "|", konsentrasi+"|");
            Console.WriteLine("|*******************************|");
        }
    }
}
