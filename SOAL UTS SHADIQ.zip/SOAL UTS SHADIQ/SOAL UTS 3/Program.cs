﻿using System;

namespace SOAL_UTS_3
{
    class Program
    {
        static void Main(string[] args)
        {
           string nama;
           int tahunlahir;
           double harga;
           tahunlahir = 0;

            Console.WriteLine("Nama :");
            nama = Console.ReadLine();
            Console.WriteLine("Tahun Lahir :");
            tahunlahir = Convert.ToInt16(Console.ReadLine());

            if (tahunlahir >= 2012)
            {
            harga = 10000;
            Console.WriteLine("|*******************************|");
            Console.WriteLine("{0,-8} {1,15} {2,8}", "|", "-- Studio 1 --","|");
            Console.WriteLine("{0,-8} {1,24}", "|Nama:", nama+"|");
            Console.WriteLine("{0,-8} {1,4} {2,19}", "|Harga:", "Rp",harga+".00|");
            Console.WriteLine("|-------------------------------|");
            }

            else if (tahunlahir <= 1962)
            {
            harga = 10000;
            Console.WriteLine("|*******************************|");
            Console.WriteLine("{0,-8} {1,15} {2,8}", "|", "-- Studio 1 --","|");
            Console.WriteLine("{0,-8} {1,24}", "|Nama:", nama+"|");
            Console.WriteLine("{0,-8} {1,4} {2,19}", "|Harga:", "Rp",harga+".00|");
            Console.WriteLine("|-------------------------------|");
            }

            else
            {
            harga = 25000;
            Console.WriteLine("|*******************************|");
            Console.WriteLine("{0,-8} {1,15} {2,8}", "|", "-- Studio 1 --","|");
            Console.WriteLine("{0,-8} {1,24}", "|Nama:", nama+"|");
            Console.WriteLine("{0,-8} {1,4} {2,19}", "|Harga:", "Rp",harga+".00|");
            Console.WriteLine("|-------------------------------|");
            }


        }
    }
}
