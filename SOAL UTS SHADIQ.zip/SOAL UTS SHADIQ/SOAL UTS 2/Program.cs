﻿using System;

namespace SOAL_UTS_2
{
    class ConvertDollar
    {
       public static void Main(string[] args)
       {
       float dollar;
       float rate;

       Console.WriteLine("Rate USD ke RP: ");
       rate = float.Parse(Console.ReadLine());

       Console.WriteLine("Jumlah USD: ");
       dollar = float.Parse(Console.ReadLine());

       Console.WriteLine("Hasil Konversi: " +rate*dollar);
       }
    }
}
